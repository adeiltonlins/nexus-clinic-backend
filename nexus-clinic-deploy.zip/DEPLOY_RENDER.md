# 🚀 DEPLOY NO RENDER - PASSO A PASSO

## 1. CRIAR CONTA NO RENDER
- Acesse: https://render.com
- Clique em "Get Started for Free"
- Escolha "Sign up with GitHub" (mais facil)

## 2. CRIAR WEB SERVICE
- No dashboard, clique em "New +" → "Web Service"
- Escolha "Upload your code" (se nao tiver GitHub)
- Ou conecte seu repositorio GitHub

## 3. CONFIGURAR O SERVICO
Preencha os campos:
- Name: nexus-clinic-backend
- Runtime: Node
- Build Command: npm install
- Start Command: node server.js
- Plan: Free

## 4. ADICIONAR ENVIRONMENT VARIABLES
Clique em "Advanced" e adicione:

SUPABASE_URL=https://yndvrcdvzhdqidirtgnx.supabase.co
SUPABASE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InluZHZyY2R2emhkcWlkaXJ0Z254Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc4NjgxNjU3MiwiZXhwIjoyMTAyMzkyNTcyfQ.hvbu_nZkjP6dUBTfiQyoZUPKufCzJ-3trJwlP-4tJGI
GEMINI_API_KEY=AQ.Ab8RN6KWT3nICGpdm5RmxOQqK3BqK6NwDVbx-vFulef0pg23DA
PORT=10000

## 5. DEPLOY
- Clique em "Create Web Service"
- Aguarde 2-3 minutos
- Pronto! 🎉

## 6. CONECTAR WHATSAPP
- Va na aba "Logs" do seu servico no Render
- Aguarde o QR Code aparecer no terminal
- No celular: WhatsApp → Configuracoes → Dispositivos conectados
- Escanee o QR Code
- PRONTO!

## 7. FRONTEND
- Abra o arquivo index.html
- Troque a URL da API pela URL do seu app no Render
- Suba no Netlify (app.netlify.com/drop - arraste a pasta)
